// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recovery_key_entity.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RecoveryKeyEntityImpl _$$RecoveryKeyEntityImplFromJson(
        Map<String, dynamic> json) =>
    _$RecoveryKeyEntityImpl(
      phrase1: json['phrase_1'] as String?,
      phrase2: json['phrase_2'] as String?,
      phrase3: json['phrase_3'] as String?,
      phrase4: json['phrase_4'] as String?,
      phrase5: json['phrase_5'] as String?,
      phrase6: json['phrase_6'] as String?,
      phrase7: json['phrase_7'] as String?,
      phrase8: json['phrase_8'] as String?,
      phrase9: json['phrase_9'] as String?,
      phrase10: json['phrase_10'] as String?,
      phrase11: json['phrase_11'] as String?,
      phrase12: json['phrase_12'] as String?,
    );

Map<String, dynamic> _$$RecoveryKeyEntityImplToJson(
        _$RecoveryKeyEntityImpl instance) =>
    <String, dynamic>{
      'phrase_1': instance.phrase1,
      'phrase_2': instance.phrase2,
      'phrase_3': instance.phrase3,
      'phrase_4': instance.phrase4,
      'phrase_5': instance.phrase5,
      'phrase_6': instance.phrase6,
      'phrase_7': instance.phrase7,
      'phrase_8': instance.phrase8,
      'phrase_9': instance.phrase9,
      'phrase_10': instance.phrase10,
      'phrase_11': instance.phrase11,
      'phrase_12': instance.phrase12,
    };
