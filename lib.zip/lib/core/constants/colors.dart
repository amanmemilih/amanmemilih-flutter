import 'package:flutter/material.dart';

const Color colorPrimary = Color(0xffFF5353);
const Color fieldDisable = Color(0xffCFCFCF);
const Color fieldTextHint = Color(0xffABABAB);
const Color buttonPressed = Color(0xffE85555);
const Color backgroundPage = Color(0xffF9F9F9);
const Color colorYellow = Color(0xffF39C45);
const Color colorGreen = Color(0xff00AA5B);
