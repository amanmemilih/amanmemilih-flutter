import 'package:flutter/material.dart';

class LOCALE {
  static const indonesia = Locale('id');
  static const english = Locale('en');
}
