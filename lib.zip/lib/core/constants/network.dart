class NETWORK {
  static const baseURL = 'http://10.0.2.2:8080/api';
}
