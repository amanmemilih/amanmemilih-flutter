class APP {
  static const name = 'AmanMemilih';
  static const appStoreID = "12345566";
  static const playStoreID = "12345566";
  static const playStoreURL = "";
  static const appStoreURL = "";
}
