class FILE {
  static const corePath = 'lib/core';
  static const featurePath = 'lib/features';
  static const localizationPath = 'lib/core/lang';
}
