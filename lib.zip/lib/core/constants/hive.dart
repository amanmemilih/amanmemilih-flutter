class HIVE {
  static const databaseName = 'amanmemilih';
  static const tokenData = 'token_data';
  static const appDownloadData = 'app_download_data';
}
