class FONT {
  static const fontPoppins = 'Poppins';
}
