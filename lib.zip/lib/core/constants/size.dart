import 'package:flutter/material.dart';

class SIZE {
  static double appBarHeight = AppBar().preferredSize.height;
}
