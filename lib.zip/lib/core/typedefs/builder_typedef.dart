import 'package:flutter/material.dart';

typedef Widget WidgetBuilder<T>(BuildContext context);
